#!/usr/bin/env python3
"""
Semi-manual GUI for particle tracking and trap stiffness estimation.
"""

from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

import cv2
import numpy as np

from particle_tracking_core import (
    build_output_table,
    estimate_stiffness,
    load_video_frames,
    track_selected_particles,
    write_dat,
)


MAX_DISPLAY_SIZE = 900


class ParticleTrackerApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Particle Tracker for Trap Stiffness")

        self.video_path: Path | None = None
        self.frames: list[np.ndarray] = []
        self.fps: float | None = None
        self.seed_points: list[tuple[float, float]] = []
        self.seed_radii: list[float] = []
        self.seed_arc_angles: list[float | None] = []
        self.tracks: np.ndarray | None = None
        self.output_table: np.ndarray | None = None
        self.output_headers: list[str] | None = None
        self.display_scale = 1.0
        self.tk_image: tk.PhotoImage | None = None
        self.drag_start: tuple[float, float] | None = None
        self.preview_circle_id: int | None = None

        self.video_var = tk.StringVar()
        self.pixel_size_var = tk.StringVar(value="1.0")
        self.temperature_var = tk.StringVar(value="25.0")
        self.roi_radius_var = tk.StringVar(value="20")
        self.template_radius_var = tk.StringVar(value="8")
        self.match_threshold_var = tk.StringVar(value="0.35")
        self.tracking_mode_var = tk.StringVar(value="Auto")
        self.selection_mode_var = tk.StringVar(value="Full circle")
        self.status_var = tk.StringVar(value="Load a video to begin.")

        self._build_ui()
        self._update_buttons()

    def _build_ui(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        controls = ttk.Frame(self.root, padding=10)
        controls.grid(row=0, column=0, sticky="ew")
        controls.columnconfigure(1, weight=1)

        ttk.Label(controls, text="Video").grid(row=0, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.video_var).grid(
            row=0, column=1, sticky="ew", padx=(6, 6)
        )
        ttk.Button(controls, text="Browse", command=self.browse_video).grid(
            row=0, column=2, sticky="ew"
        )
        ttk.Button(controls, text="Load", command=self.load_video).grid(
            row=0, column=3, sticky="ew", padx=(6, 0)
        )

        ttk.Label(controls, text="Pixel size (um/px)").grid(row=1, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.pixel_size_var, width=12).grid(
            row=1, column=1, sticky="w", padx=(6, 6)
        )
        ttk.Label(controls, text="Temperature (C)").grid(row=1, column=2, sticky="e")
        ttk.Entry(controls, textvariable=self.temperature_var, width=12).grid(
            row=1, column=3, sticky="w", padx=(6, 0)
        )

        ttk.Label(controls, text="Search radius (px)").grid(row=2, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.roi_radius_var, width=12).grid(
            row=2, column=1, sticky="w", padx=(6, 6)
        )
        ttk.Label(controls, text="Template radius (px)").grid(row=2, column=2, sticky="e")
        ttk.Entry(controls, textvariable=self.template_radius_var, width=12).grid(
            row=2, column=3, sticky="w", padx=(6, 0)
        )

        ttk.Label(controls, text="Match threshold").grid(row=3, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.match_threshold_var, width=12).grid(
            row=3, column=1, sticky="w", padx=(6, 6)
        )
        ttk.Label(controls, text="Particle type").grid(row=3, column=2, sticky="e")
        ttk.Combobox(
            controls,
            textvariable=self.tracking_mode_var,
            values=("Auto", "Bright spot", "Ring / hollow"),
            state="readonly",
            width=14,
        ).grid(row=3, column=3, sticky="w", padx=(6, 0))
        ttk.Label(controls, text="Selection").grid(row=4, column=0, sticky="w")
        ttk.Combobox(
            controls,
            textvariable=self.selection_mode_var,
            values=("Full circle", "Half circle / arc"),
            state="readonly",
            width=14,
        ).grid(row=4, column=1, sticky="w", padx=(6, 6))

        action_bar = ttk.Frame(controls)
        action_bar.grid(row=5, column=0, columnspan=4, sticky="ew", pady=(8, 0))
        action_bar.columnconfigure(5, weight=1)

        self.undo_button = ttk.Button(action_bar, text="Undo Last", command=self.undo_last)
        self.undo_button.grid(row=0, column=0, padx=(0, 6))
        self.clear_button = ttk.Button(action_bar, text="Clear All", command=self.clear_points)
        self.clear_button.grid(row=0, column=1, padx=(0, 6))
        self.track_button = ttk.Button(action_bar, text="Start Tracking", command=self.start_tracking)
        self.track_button.grid(row=0, column=2, padx=(0, 6))
        self.save_button = ttk.Button(action_bar, text="Save .dat", command=self.save_dat)
        self.save_button.grid(row=0, column=3, padx=(0, 6))
        ttk.Label(action_bar, textvariable=self.status_var).grid(row=0, column=5, sticky="e")

        content = ttk.Panedwindow(self.root, orient=tk.HORIZONTAL)
        content.grid(row=1, column=0, sticky="nsew")

        viewer_frame = ttk.Frame(content, padding=(10, 0, 10, 10))
        viewer_frame.columnconfigure(0, weight=1)
        viewer_frame.rowconfigure(0, weight=1)
        content.add(viewer_frame, weight=3)

        self.canvas = tk.Canvas(viewer_frame, background="black", highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.canvas.bind("<ButtonPress-1>", self.on_canvas_press)
        self.canvas.bind("<B1-Motion>", self.on_canvas_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_canvas_release)

        results_frame = ttk.Frame(content, padding=(0, 0, 10, 10))
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(1, weight=1)
        content.add(results_frame, weight=2)

        ttk.Label(
            results_frame,
            text="Results",
            font=("Segoe UI", 11, "bold"),
        ).grid(row=0, column=0, sticky="w")

        self.results_text = tk.Text(results_frame, width=45, height=28, state="disabled")
        self.results_text.grid(row=1, column=0, sticky="nsew")

    def _update_buttons(self) -> None:
        loaded = bool(self.frames)
        has_points = bool(self.seed_points)
        has_output = self.output_table is not None and self.output_headers is not None
        self.undo_button.configure(state="normal" if has_points else "disabled")
        self.clear_button.configure(state="normal" if has_points else "disabled")
        self.track_button.configure(state="normal" if loaded and has_points else "disabled")
        self.save_button.configure(state="normal" if has_output else "disabled")

    def browse_video(self) -> None:
        selected = filedialog.askopenfilename(
            title="Select video",
            filetypes=[
                ("Video files", "*.mp4 *.avi *.mov *.mkv *.wmv *.mpg *.mpeg"),
                ("All files", "*.*"),
            ],
        )
        if selected:
            self.video_var.set(selected)

    def load_video(self) -> None:
        video_text = self.video_var.get().strip()
        if not video_text:
            messagebox.showerror("Missing video", "Choose a video file first.")
            return

        video_path = Path(video_text)
        if not video_path.exists():
            messagebox.showerror("Missing video", f"File not found:\n{video_path}")
            return

        try:
            frames, fps = load_video_frames(video_path)
        except Exception as exc:
            messagebox.showerror("Load failed", str(exc))
            return

        self.video_path = video_path
        self.frames = frames
        self.fps = fps
        self.seed_points = []
        self.seed_radii = []
        self.seed_arc_angles = []
        self.tracks = None
        self.output_table = None
        self.output_headers = None
        self._display_frame(frames[0])
        self._set_results_text(
            f"Loaded {video_path.name}\n"
            f"Frames: {len(frames)}\n"
            f"FPS: {fps:.3f}\n\n"
            "Draw one circle around each particle in the first frame.\n"
            "For overlapping rings, switch Selection to Half circle / arc and drag toward the clean side of the ring."
        )
        self.status_var.set("Video loaded. Draw circles around particles in order.")
        self._update_buttons()

    def _frame_to_photoimage(self, frame: np.ndarray) -> tk.PhotoImage:
        if frame.ndim == 2:
            rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        height, width = rgb.shape[:2]
        scale = min(MAX_DISPLAY_SIZE / max(width, 1), MAX_DISPLAY_SIZE / max(height, 1), 1.0)
        scaled_width = max(1, int(round(width * scale)))
        scaled_height = max(1, int(round(height * scale)))
        if scale != 1.0:
            rgb = cv2.resize(rgb, (scaled_width, scaled_height), interpolation=cv2.INTER_AREA)

        self.display_scale = scale
        ppm_header = f"P6 {scaled_width} {scaled_height} 255 ".encode("ascii")
        ppm_data = ppm_header + rgb.astype(np.uint8).tobytes()
        return tk.PhotoImage(data=ppm_data, format="PPM")

    def _display_frame(self, frame: np.ndarray) -> None:
        self.tk_image = self._frame_to_photoimage(frame)
        self.canvas.configure(
            width=self.tk_image.width(),
            height=self.tk_image.height(),
        )
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_image)
        self._draw_seed_markers()

    def _draw_seed_markers(self) -> None:
        for idx, ((x, y), radius_px, arc_angle) in enumerate(
            zip(self.seed_points, self.seed_radii, self.seed_arc_angles), start=1
        ):
            cx = x * self.display_scale
            cy = y * self.display_scale
            radius = max(6.0, radius_px * self.display_scale)
            if arc_angle is None:
                self.canvas.create_oval(
                    cx - radius,
                    cy - radius,
                    cx + radius,
                    cy + radius,
                    outline="#00ff99",
                    width=2,
                )
            else:
                start = arc_angle - 90.0
                self.canvas.create_arc(
                    cx - radius,
                    cy - radius,
                    cx + radius,
                    cy + radius,
                    start=start,
                    extent=180.0,
                    style=tk.ARC,
                    outline="#00ff99",
                    width=2,
                )
            self.canvas.create_line(cx - 4, cy, cx + 4, cy, fill="#00ff99", width=2)
            self.canvas.create_line(cx, cy - 4, cx, cy + 4, fill="#00ff99", width=2)
            self.canvas.create_text(
                cx + 10,
                cy - 10,
                text=f"p{idx}",
                anchor="sw",
                fill="#00ff99",
                font=("Segoe UI", 10, "bold"),
            )

    def on_canvas_press(self, event: tk.Event[tk.Misc]) -> None:
        if not self.frames:
            return
        self.drag_start = (event.x / self.display_scale, event.y / self.display_scale)
        if self.preview_circle_id is not None:
            self.canvas.delete(self.preview_circle_id)
            self.preview_circle_id = None

    def on_canvas_drag(self, event: tk.Event[tk.Misc]) -> None:
        if not self.frames or self.drag_start is None:
            return
        start_x, start_y = self.drag_start
        end_x = event.x / self.display_scale
        end_y = event.y / self.display_scale
        radius = max(2.0, float(np.hypot(end_x - start_x, end_y - start_y)))
        cx = start_x * self.display_scale
        cy = start_y * self.display_scale
        draw_radius = radius * self.display_scale
        angle = float(np.degrees(np.arctan2(-(end_y - start_y), end_x - start_x)))
        if self.preview_circle_id is not None:
            self.canvas.delete(self.preview_circle_id)
        if self.selection_mode_var.get() == "Half circle / arc":
            self.preview_circle_id = self.canvas.create_arc(
                cx - draw_radius,
                cy - draw_radius,
                cx + draw_radius,
                cy + draw_radius,
                start=angle - 90.0,
                extent=180.0,
                style=tk.ARC,
                outline="#66ccff",
                width=2,
                dash=(4, 3),
            )
        else:
            self.preview_circle_id = self.canvas.create_oval(
                cx - draw_radius,
                cy - draw_radius,
                cx + draw_radius,
                cy + draw_radius,
                outline="#66ccff",
                width=2,
                dash=(4, 3),
            )

    def on_canvas_release(self, event: tk.Event[tk.Misc]) -> None:
        if not self.frames or self.drag_start is None:
            return
        start_x, start_y = self.drag_start
        end_x = event.x / self.display_scale
        end_y = event.y / self.display_scale
        radius = max(2.0, float(np.hypot(end_x - start_x, end_y - start_y)))
        arc_angle = None
        if self.selection_mode_var.get() == "Half circle / arc":
            arc_angle = float(np.degrees(np.arctan2(-(end_y - start_y), end_x - start_x)))
        self.seed_points.append((float(start_x), float(start_y)))
        self.seed_radii.append(radius)
        self.seed_arc_angles.append(arc_angle)
        self.drag_start = None
        if self.preview_circle_id is not None:
            self.canvas.delete(self.preview_circle_id)
            self.preview_circle_id = None
        self.tracks = None
        self.output_table = None
        self.output_headers = None
        self._display_frame(self.frames[0])
        self.status_var.set(f"Selected {len(self.seed_points)} particle region(s).")
        self._update_buttons()

    def undo_last(self) -> None:
        if not self.seed_points:
            return
        self.seed_points.pop()
        self.seed_radii.pop()
        self.seed_arc_angles.pop()
        self.tracks = None
        self.output_table = None
        self.output_headers = None
        self._display_frame(self.frames[0])
        self.status_var.set(f"Selected {len(self.seed_points)} particle(s).")
        self._update_buttons()

    def clear_points(self) -> None:
        self.seed_points = []
        self.seed_radii = []
        self.seed_arc_angles = []
        self.drag_start = None
        self.preview_circle_id = None
        self.tracks = None
        self.output_table = None
        self.output_headers = None
        if self.frames:
            self._display_frame(self.frames[0])
        self.status_var.set("Selection cleared.")
        self._update_buttons()

    def _read_positive_float(self, text: str, name: str) -> float:
        try:
            value = float(text)
        except ValueError as exc:
            raise RuntimeError(f"{name} must be a number.") from exc
        if value <= 0:
            raise RuntimeError(f"{name} must be positive.")
        return value

    def _read_positive_int(self, text: str, name: str) -> int:
        try:
            value = int(text)
        except ValueError as exc:
            raise RuntimeError(f"{name} must be an integer.") from exc
        if value <= 0:
            raise RuntimeError(f"{name} must be positive.")
        return value

    def start_tracking(self) -> None:
        if not self.frames or self.video_path is None or self.fps is None:
            messagebox.showerror("No video", "Load a video before tracking.")
            return
        if not self.seed_points:
            messagebox.showerror("No particles", "Draw at least one particle circle first.")
            return

        try:
            pixel_size = self._read_positive_float(
                self.pixel_size_var.get(), "Pixel size"
            )
            temperature_c = self._read_positive_float(
                self.temperature_var.get(), "Temperature"
            )
            roi_radius = self._read_positive_int(
                self.roi_radius_var.get(), "Search radius"
            )
            template_radius = self._read_positive_int(
                self.template_radius_var.get(), "Template radius"
            )
            match_threshold = self._read_positive_float(
                self.match_threshold_var.get(), "Match threshold"
            )
            tracking_mode = {
                "Auto": "auto",
                "Bright spot": "bright",
                "Ring / hollow": "ring",
            }[self.tracking_mode_var.get()]
        except RuntimeError as exc:
            messagebox.showerror("Invalid settings", str(exc))
            return

        self.status_var.set("Tracking particles...")
        self.root.update_idletasks()
        temperature_k = temperature_c + 273.15

        try:
            tracks, _ = track_selected_particles(
                frames=self.frames,
                seed_points=self.seed_points,
                seed_radii=self.seed_radii,
                seed_arc_angles=self.seed_arc_angles,
                roi_radius=roi_radius,
                template_radius=template_radius,
                blur_size=5,
                refine_radius=max(3, template_radius // 2),
                min_match_score=match_threshold,
                min_contrast=10.0,
                tracking_mode=tracking_mode,
            )
        except Exception as exc:
            messagebox.showerror("Tracking failed", str(exc))
            self.status_var.set("Tracking failed.")
            return

        table, headers = build_output_table(
            tracks=tracks,
            fps=self.fps,
            pixel_size=pixel_size,
        )
        stiffness = estimate_stiffness(
            table=table,
            headers=headers,
            pixel_size_um=pixel_size,
            temperature_k=temperature_k,
        )

        self.tracks = tracks
        self.output_table = table
        self.output_headers = headers
        self._show_tracking_overlay(tracks[-1])
        self._set_results_text(
            self._format_results(
                stiffness,
                tracks,
                pixel_size,
                temperature_c,
                self.tracking_mode_var.get(),
            )
        )
        self.status_var.set(
            f"Tracked {tracks.shape[1]} particle(s) across {tracks.shape[0]} frames."
        )
        self._update_buttons()

    def _show_tracking_overlay(self, points: np.ndarray) -> None:
        if not self.frames:
            return
        self._display_frame(self.frames[0])
        for idx, point in enumerate(points, start=1):
            cx = float(point[0]) * self.display_scale
            cy = float(point[1]) * self.display_scale
            radius = 7
            self.canvas.create_oval(
                cx - radius,
                cy - radius,
                cx + radius,
                cy + radius,
                outline="#ffcc00",
                width=2,
            )
            self.canvas.create_line(cx - 5, cy, cx + 5, cy, fill="#ffcc00", width=2)
            self.canvas.create_line(cx, cy - 5, cx, cy + 5, fill="#ffcc00", width=2)
            self.canvas.create_text(
                cx + 10,
                cy + 10,
                text=f"end p{idx}",
                anchor="nw",
                fill="#ffcc00",
                font=("Segoe UI", 9, "bold"),
            )

    def _format_results(
        self,
        stiffness: list[dict[str, float]],
        tracks: np.ndarray,
        pixel_size: float,
        temperature: float,
        tracking_mode: str,
    ) -> str:
        lines = [
            f"Tracked particles: {tracks.shape[1]}",
            f"Frames: {tracks.shape[0]}",
            f"FPS: {self.fps:.3f}" if self.fps is not None else "FPS: unknown",
            f"Pixel size: {pixel_size:.6f} um/px",
            f"Temperature: {temperature:.2f} C",
            f"Tracking mode: {tracking_mode}",
            "",
            "column\tvariance_px2\tvariance_um2\tk_pN_per_um\tk_pN_per_nm",
        ]
        for row in stiffness:
            lines.append(
                f"{row['column']}\t{row['variance_px2']:.8f}\t"
                f"{row['variance_um2']:.8f}\t{row['k_pn_per_um']:.6f}\t{row['k_pn_per_nm']:.6f}"
            )
        lines.extend(
            [
                "",
                "Use Save .dat to export the tracked coordinates and displacements.",
            ]
        )
        return "\n".join(lines)

    def _set_results_text(self, text: str) -> None:
        self.results_text.configure(state="normal")
        self.results_text.delete("1.0", tk.END)
        self.results_text.insert("1.0", text)
        self.results_text.configure(state="disabled")

    def save_dat(self) -> None:
        if (
            self.output_table is None
            or self.output_headers is None
            or self.video_path is None
            or self.fps is None
        ):
            messagebox.showerror("No data", "Track particles before saving.")
            return

        try:
            pixel_size = self._read_positive_float(
                self.pixel_size_var.get(), "Pixel size"
            )
            temperature_c = self._read_positive_float(
                self.temperature_var.get(), "Temperature"
            )
        except RuntimeError as exc:
            messagebox.showerror("Invalid settings", str(exc))
            return
        temperature_k = temperature_c + 273.15

        default_name = self.video_path.stem + "_tracked.dat"
        output = filedialog.asksaveasfilename(
            title="Save displacement data",
            defaultextension=".dat",
            initialfile=default_name,
            filetypes=[("DAT files", "*.dat"), ("All files", "*.*")],
        )
        if not output:
            return

        output_path = Path(output)
        try:
            write_dat(
                output_path=output_path,
                table=self.output_table,
                headers=self.output_headers,
                unit="um",
                pixel_size=pixel_size,
                fps=self.fps,
                video_path=self.video_path,
                temperature_k=temperature_k,
            )
        except Exception as exc:
            messagebox.showerror("Save failed", str(exc))
            return

        self.status_var.set(f"Saved results to {output_path.name}.")
        messagebox.showinfo("Saved", f"Saved tracked motion to:\n{output_path}")


def main() -> None:
    root = tk.Tk()
    app = ParticleTrackerApp(root)
    root.minsize(1100, 700)
    root.mainloop()


if __name__ == "__main__":
    main()
